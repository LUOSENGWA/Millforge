---
name: teamharness-task-execution
description: "Use when you act as Worker: receive TASK_ASSIGNED, acknowledge the task, work inside shared/tasks/{task-id}/, submit with taskflow submit_task, publish deliverables through submit_task, and report TASK_COMPLETED or blockers in the Task room."
---

# Task Execution

Use this skill when executing assigned work as a Worker or remote member.

Claim only tasks assigned to you. Read the task spec, keep deliverables in the
task directory, ask focused blocker questions, and submit a structured result.

Do not change project-level state or project result files.

Do not use this skill or taskflow for readiness checks, direct questions, or
explicit requests to reply with specific text. Answer those directly in the
current room.

## Task Directory

Your assigned task lives under:

```text
shared/tasks/{task-id}/
```

Your Leader owns:

```text
shared/tasks/{task-id}/meta.json
shared/tasks/{task-id}/spec.md
```

You own:

```text
shared/tasks/{task-id}/workspace/
shared/tasks/{task-id}/progress/
shared/tasks/{task-id}/result.md
```

Do not edit:

```text
shared/projects/{project-id}/meta.json
shared/projects/{project-id}/plan.md
shared/projects/{project-id}/result.md
```

If a task spec asks you to write or submit `shared/projects/...`, report that
boundary conflict to the Leader. Put Worker-owned deliverables under
`shared/tasks/{task-id}/...`; your Leader owns project-level reports.

## Acknowledge

When you are mentioned with `TASK_ASSIGNED`, first pull or inspect the task
directory if needed, then acknowledge with `taskflow`:

```json
{
  "role": "worker",
  "action": "ack_task",
  "payload": {
    "taskId": "demo-project-001-01"
  }
}
```

If `ack_task` fails because the task is missing or assigned elsewhere, stop and
report the blocker to the Leader in the current room. Do not invent task files.

Read:

```text
shared/tasks/{task-id}/spec.md
```

before doing the work.

## Execute

Keep all deliverables under the task directory. If you need private notes, use:

```text
shared/tasks/{task-id}/workspace/
```

Use meaningful filenames for deliverables. Prefer names that describe the
artifact's purpose, such as `analysis.md`, `trace-summary.log`, or
`patch-notes.md`; avoid vague names like `output.md` when there are multiple
files.

For report-style tasks whose expected output is `shared/tasks/{task-id}/result.md`,
write the full report content to that file before calling `submit_task`.
`submit_task` records structured status in task metadata and does not create or
rewrite `result.md`.

For long-running tasks, report progress periodically with the `report_progress`
action (a short `note`, ≤ 200 chars). It records a progress entry in the task's
audit history without changing task state or notifying the room — use it to make
multi-stage work visible, not as a status update.

If blocked, submit a `BLOCKED` result instead of silently waiting.

## Coding CLI runs (when used)

If this task is executed through a coding CLI (`run-coding-cli.sh` / Qwen
Code), keep the workflow view in this **same task** — do not create a second
task:

1. Before dispatch, record it with `report_progress`:
   `coding-cli:<cli> run=<run_id> dispatched` (≤ 200 chars).
2. When the CLI finishes, that is **not** the task result. Review the generated
   changes, then check them against the task's acceptance criteria:
   - whole task complete and criteria pass -> submit `SUCCESS` /
     `SUCCESS_WITH_NOTES` (put the run id in the summary);
   - more work remains -> keep reporting progress
     (`coding-cli:<cli> run=<run_id> completed; remaining: <...>`) and continue;
   - blocked or interrupted -> `BLOCKED` / `INTERRUPTED`.
   A successful CLI run is one step of the task, not the task outcome.
3. The Worker owns starting/stopping the CLI; **workflow cancellation**
   (`cancel_task`) stays Leader-only. Report a stopped run, then let the
   Leader cancel the task if the task itself is cancelled.

## Submit

Submit with `taskflow`:

```json
{
  "role": "worker",
  "action": "submit_task",
  "payload": {
    "taskId": "demo-project-001-01",
    "status": "SUCCESS",
    "summary": "Completed the assigned work.",
    "conclusions": [
      "The deliverable is at shared/tasks/demo-project-001-01/workspace/output.md.",
      "Acceptance criteria 1-3 all pass.",
      "No follow-up work remains."
    ],
    "deliverables": [
      "shared/tasks/demo-project-001-01/workspace/output.md"
    ]
  }
}
```

The `conclusions` array is part of the completion report: 3-5 short
one-line strings stating what was done, what was verified, and what (if
anything) is left open. Fewer than 3 comes back as a warning on the tool
result (and is rejected outright when the runtime runs with
`AGENTTEAMS_TASK_CONCLUSIONS_STRICT` on); more than 5 are all recorded in
the task meta, but the completion event shows only the first 5 with a
pointer to the meta file. Conclusions are not part of the submission
digest, so an exact retry of status/summary/deliverables may still carry
a repaired list.

Use one of:

- `SUCCESS`
- `SUCCESS_WITH_NOTES`
- `PARTIAL`
- `REVISION_NEEDED`
- `BLOCKED`
- `INTERRUPTED`

Use `INTERRUPTED` when execution stopped before you could finish. If your Leader
accepts either `INTERRUPTED` or `BLOCKED`, TeamHarness records the task and plan
node as `blocked` and resolves the continuation with `resolution: blocked`.

Your first persisted submission records `submission_id`, UTC `submitted_at`,
`result_digest`, and a pending `continuation` marker in TaskMeta. Treat
`submission_id` as an opaque fence: compare it for equality, but do not parse it
or assume a UUID format. The digest covers your trimmed status, whitespace-
collapsed summary, and validated deliverable paths in their persisted order; it does
not cover notes or the rendered `result.md` text.

If shared-storage sync is interrupted, retry with exactly the same status,
summary, and ordered deliverables. Your retry reuses the original submission,
timestamp, digest, and continuation `delivery_id`, and repairs missing project
or task projections. If you change any digest input, the retry conflicts with
the submitted task and you must wait for a Leader decision or a new task. A
pending continuation is durable state for a future Controller; it does not mean
that a Matrix wake was sent or that your Leader has already resumed the task.

You cannot accept, reject, cancel, or resolve your own submission. Those are
trusted-Leader-only decisions, and putting `role: leader` in a payload cannot
override your Worker runtime identity. After submitting, use the returned
`submissionId` only as an opaque value in reports or exact retries.

For a legacy task already marked `submitted` without a submission identity,
retry only when TaskMeta has `submitted_at`, and send the complete original
status, summary, and ordered deliverables. CoPaw adopts it only if that result
exactly matches the persisted result; otherwise it fails closed. Do not invent
an identity or try to resolve the legacy task yourself.

Submitting ends the task. Do not keep editing the old task after submission
unless the Leader assigns a new task.

If you already wrote a detailed `shared/tasks/{task-id}/result.md`, include that
path in `deliverables`; do not replace the report with only a short summary.
Do not include `shared/projects/...` paths in `deliverables`.

When Matrix room context is available, `submit_task` automatically publishes
`shared/tasks/{task-id}/result.md` and eligible deliverable files under the
current task directory as Matrix `m.file` events. Check `publishedArtifacts` in
the tool result for published, skipped, or failed artifact status. Do not upload
task artifacts manually with `message` just to make them appear in the room
file panel.

## Completion Message

`submit_task` automatically publishes the completion event to the Task room:
the first line is the contract below, and the event @mentions the Leader
and the human members of the team (the task initiator), so the requester is
routed with the same salience the leader is. After `submit_task` returns
`ok: true`, do not send another completion line.

The event first line carries one token per result status (code-generated):

```text
@leader-user:matrix.local TASK_COMPLETED: demo-project-001-01 - Result: shared/tasks/demo-project-001-01/result.md
@leader-user:matrix.local TASK_REVISION_NEEDED: demo-project-001-01 - <summary>
@leader-user:matrix.local TASK_BLOCKED: demo-project-001-01 - <short blocker summary>
@leader-user:matrix.local TASK_INTERRUPTED: demo-project-001-01 - <summary>
```

When the submission carried `conclusions`, the event appends a
`- Conclusions:` block (numbered one-line entries, first 5 only, then a
pointer to `shared/tasks/{task-id}/meta.json` when more were recorded)
after the Worker/Status lines. The first line and the Result/Worker/Status
lines stay the contract above; a submission without conclusions keeps the
event byte-identical to the legacy format.

If the task spec gives an exact completion line, the code event keeps that
line format; a short human-readable summary message may still follow in the
room but never replaces the event. Do not use `NO_REPLY` after successful
submission.

While the task is still in flight and you need a human decision (approval /
decision / escalation) instead of guessing, call `taskflow` with
`action: request_attention` (payload: `kind`, `question`, `options`,
`suggested`, `expiresAt`). `options` is a list of `{id, label}` pairs
(at most 10) — the exact ids a human answer must echo; `suggested` is one
of those option ids (advisory only, never applied automatically);
`expiresAt` is an optional ISO 8601 deadline recorded on the request.
Decision-type requests (`kind: decision`) must provide `options` —
without them the human cannot answer structurally. Do not rely on the
human noticing an ambient room message. Once the decision is made, close
the loop by calling again with the same `kind` plus `resolved: true` —
closing needs an existing record of that kind (it is rejected without
one) and reuses the original event (no new ping).
