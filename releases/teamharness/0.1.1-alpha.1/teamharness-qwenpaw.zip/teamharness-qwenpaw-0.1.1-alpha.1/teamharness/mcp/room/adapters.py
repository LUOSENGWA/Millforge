# Room channel adapters (TH-3): the notification seam per delivery
# channel. MatrixRoomAdapter is the default implementation — the
# pre-TH-3 attention send path promoted to a formal adapter (wire
# behaviour unchanged).
from __future__ import annotations

import json

import os

import urllib.error

import urllib.parse

import urllib.request

from typing import Any

from typing import Protocol

from typing import runtime_checkable

from mcp.common import refs
from .mention import _matrix_content

# Monkeypatch-sensitive (15-name set): the membership check is owned by
# notify.py (defined and proxied there) — resolve at call time so a
# test patch of server._validate_assignee_membership stays visible at
# the adapter's call site.
_validate_assignee_membership = refs.proxy("_validate_assignee_membership")


@runtime_checkable
class RoomAdapter(Protocol):
    """A room notification channel (TH-3).

    ``send`` delivers one attention notification to a room and returns
    the send result plus a per-recipient delivery receipt:

    - ``recipients[]`` — one entry per recipient the channel reached
      (``{"mxid", "role", "delivered"}``). Channels that have a
      per-recipient receipt additionally report ``accepted`` per
      recipient. A channel without receipts (Matrix) omits the field:
      for Matrix the per-recipient acceptance is always null, never
      inferred from ``delivered``.
    - ``gaps[]`` — one entry per recipient the channel could not reach
      (``{"recipient", "role", "reason"(, "error")}``); ``reason`` is
      from the frozen NOTIFICATION_GAP_REASONS vocabulary (notify.py).
    - ``channel_accepted`` — the channel acceptance report for this
      send, produced ONLY at this boundary. Callers copy it into the
      notification_log; they never compute or infer it from
      ``sent`` / room acceptance. Channels without a receipt report
      ``None`` (Matrix: always ``None``).
    """

    #: channel name ("matrix" for the default implementation)
    name: str

    def send(
        self,
        *,
        room_id: str,
        task_id: str,
        kind: str,
        question: str,
        leader: str,
        worker: str = "",
        humans: list[str] | None = None,
        attempt: int = 1,
    ) -> dict[str, Any]:
        """Deliver one attention notification; see the class docstring."""
        ...


class MatrixRoomAdapter:
    """The default room channel: a Matrix homeserver message send.

    Promotes the pre-TH-3 behaviour of
    notify._send_attention_notification to a formal adapter — same
    text, mentions, transaction id and retry semantics, byte-identical
    wire behaviour. Matrix has no per-recipient delivery receipt: a
    successful room send only proves the homeserver accepted the event
    (room acceptance), so ``channel_accepted`` is reported as
    ``None`` for every send and the per-recipient ``accepted`` field
    is omitted from the receipt.
    """

    name = "matrix"

    def send(
        self,
        *,
        room_id: str,
        task_id: str,
        kind: str,
        question: str,
        leader: str,
        worker: str = "",
        humans: list[str] | None = None,
        attempt: int = 1,
    ) -> dict[str, Any]:
        homeserver = os.getenv("AGENTTEAMS_MATRIX_URL", "").rstrip("/")
        token = os.getenv("AGENTTEAMS_WORKER_MATRIX_TOKEN", "")
        if not homeserver or not token:
            return {
                "sent": False,
                "error": "AGENTTEAMS_MATRIX_URL and AGENTTEAMS_WORKER_MATRIX_TOKEN are required",
                "recipients": [],
                "gaps": [{"reason": "matrix_env_missing"}],
                "channel_accepted": None,
            }

        matrix_room_id = str(room_id or "").strip()
        if matrix_room_id.startswith("room:"):
            matrix_room_id = matrix_room_id[len("room:") :].strip()
        if not matrix_room_id.startswith("!"):
            return {
                "sent": False,
                "error": f"invalid Matrix room target: {room_id}",
                "recipients": [],
                "gaps": [{"reason": "no_room_id"}],
                "channel_accepted": None,
            }

        # Per-recipient membership check: every human is verified against
        # the task room; a failed or unverifiable check lands in gaps with
        # its error and never blocks the leader ping. The mention set is
        # unchanged from the pre-receipt behavior (all team humans).
        unique_humans: list[str] = []
        for human in humans or []:
            if human and human != leader and human not in unique_humans:
                unique_humans.append(human)
        verified_humans: list[str] = []
        human_gaps: list[dict[str, Any]] = []
        for human in unique_humans:
            check = _validate_assignee_membership(matrix_room_id, human)
            if check.get("ok"):
                verified_humans.append(human)
            else:
                gap: dict[str, Any] = {
                    "recipient": human,
                    "role": "human",
                    "reason": "human_not_in_room",
                }
                if check.get("error"):
                    gap["error"] = str(check["error"])[:300]
                human_gaps.append(gap)

        def _receipt(sent_ok: bool) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
            recipients = [{"mxid": leader, "role": "leader", "delivered": sent_ok}]
            for human in verified_humans:
                recipients.append({"mxid": human, "role": "human", "delivered": sent_ok})
            return recipients, list(human_gaps)

        question_preview = (question or "")[:500]
        if len(question or "") > 500:
            question_preview += "..."
        notification_text = f"{leader} ATTENTION_{kind.upper()}: {task_id} - {question_preview}".rstrip()
        if worker:
            notification_text += f"\n- Worker: {worker}"
        mentions = [leader]
        for human in humans or []:
            if human and human != leader and human not in mentions:
                mentions.append(human)
        content = _matrix_content(notification_text, mentions)

        room_enc = urllib.parse.quote(matrix_room_id, safe="")
        txn = urllib.parse.quote(f"attention-{task_id}-{kind}-{attempt}", safe="")
        url = f"{homeserver}/_matrix/client/v3/rooms/{room_enc}/send/m.room.message/{txn}"
        request = urllib.request.Request(
            url,
            data=json.dumps(content).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            method="PUT",
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                data = json.loads(response.read().decode("utf-8") or "{}")
            event_id = str(data.get("event_id") or "").strip()
            if not event_id:
                error = "Matrix send returned no event_id"
                recipients, gaps = _receipt(False)
                gaps.append({"reason": "room_send_failed", "error": error})
                return {
                    "sent": False,
                    "error": error,
                    "recipients": recipients,
                    "gaps": gaps,
                    "channel_accepted": None,
                }
            recipients, gaps = _receipt(True)
            return {
                "sent": True,
                "eventId": event_id,
                "roomId": matrix_room_id,
                "leader": leader,
                "humans": mentions[1:],
                "recipients": recipients,
                "gaps": gaps,
                "channel_accepted": None,
            }
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")[:200]
            error = f"Matrix API error: HTTP {exc.code}: {body}"
            recipients, gaps = _receipt(False)
            gaps.append({"reason": "room_send_failed", "error": error[:300]})
            return {
                "sent": False,
                "error": error,
                "recipients": recipients,
                "gaps": gaps,
                "channel_accepted": None,
            }
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            error = f"Matrix API error: {exc}"
            recipients, gaps = _receipt(False)
            gaps.append({"reason": "room_send_failed", "error": error[:300]})
            return {
                "sent": False,
                "error": error,
                "recipients": recipients,
                "gaps": gaps,
                "channel_accepted": None,
            }


def get_room_adapter() -> RoomAdapter:
    """Resolve the active room channel adapter (call-time).

    The default is the Matrix adapter; tests (and future channel
    selection) replace this at the seam — a replacement may be any
    RoomAdapter (e.g. a second channel with per-recipient receipts).
    """
    return MatrixRoomAdapter()


# Monkeypatch-sensitive (15-name set): register the real object so the
# call sites resolve it at call time against the bound server copy (a
# test patch of server.get_room_adapter stays visible there).
refs.define("get_room_adapter", get_room_adapter)
