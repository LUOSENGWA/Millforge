# IM card channel for out-of-room humans (TH-5, optional, P3): a human
# the Matrix task room cannot reach gets an attention card rendered
# from the S0 record fields; a resolve on any side closes every open
# card for the task. No IM SDK is wired here: the module defines the
# ImCardAdapter seam, renders the card from the record, and ships a
# no-op default plus a process-local in-memory implementation (tests
# and future channel selection). The Matrix notification text,
# transaction ids and retry semantics are untouched.
from __future__ import annotations

import datetime

from typing import Any

from typing import Protocol

from typing import runtime_checkable

from mcp.common import refs


@runtime_checkable
class ImCardAdapter(Protocol):
    """An out-of-band card channel for attention (TH-5).

    Only a human the task room could NOT reach (a ``human_not_in_room``
    gap on the room send) is carded; a human in the room stays on the
    Matrix path and never sees a card. Cards render from the S0
    attention record fields (question/options/timeout + the resolved
    state and its provenance once closed).

    - ``raise_card`` opens (or refreshes, idempotent per task + kind +
      human) one card for one human on one open record.
    - ``close_cards`` closes EVERY open card for the task. Idempotent:
      a second call closes nothing and reports zero.
    """

    #: channel name ("noop" / "memory" for the shipped implementations)
    name: str

    def raise_card(
        self, *, task_id: str, human: str, record: dict[str, Any]
    ) -> dict[str, Any]:
        """Open or refresh the human's card on this record."""
        ...

    def close_cards(self, *, task_id: str) -> dict[str, Any]:
        """Close every open card for the task; see the class docstring."""
        ...


def render_im_card(record: dict[str, Any]) -> dict[str, Any]:
    """Render the card body from the S0 attention record fields.

    Pure over the record: ``kind`` / ``question`` / ``options`` /
    ``suggested`` / ``timeoutAt`` (the ``expiresAt`` compatibility
    alias is honoured when the caller only wrote it) and the resolved
    state with its S0 provenance (``resolvedVia`` / ``resolvedBy`` /
    ``resolvedAt``). A copy is returned — the record is never aliased
    into the card, so a later resolve cannot mutate an open card.
    """
    card: dict[str, Any] = {
        "kind": str(record.get("kind") or ""),
        "question": str(record.get("question") or ""),
        "options": [
            dict(option)
            for option in (record.get("options") or [])
            if isinstance(option, dict)
        ],
        "resolved": bool(record.get("resolved")),
    }
    suggested = str(record.get("suggested") or "").strip()
    if suggested:
        card["suggested"] = suggested
    timeout_at = str(record.get("timeoutAt") or record.get("expiresAt") or "").strip()
    if timeout_at:
        card["timeoutAt"] = timeout_at
    if card["resolved"]:
        card["resolvedVia"] = str(record.get("resolvedVia") or "")
        resolved_by = str(record.get("resolvedBy") or "").strip()
        if resolved_by:
            card["resolvedBy"] = resolved_by
        resolved_at = str(record.get("resolvedAt") or "").strip()
        if resolved_at:
            card["resolvedAt"] = resolved_at
    return card


class NoOpImCardAdapter:
    """The default card channel: cards disabled.

    Every call reports its skip and touches nothing — the room send is
    the only notification that goes out (the pre-TH-5 behaviour).
    """

    name = "noop"

    def raise_card(
        self, *, task_id: str, human: str, record: dict[str, Any]
    ) -> dict[str, Any]:
        return {
            "opened": False,
            "skipped": True,
            "reason": "im_cards_disabled",
            "task_id": task_id,
            "human": human,
        }

    def close_cards(self, *, task_id: str) -> dict[str, Any]:
        return {
            "closed": 0,
            "skipped": True,
            "reason": "im_cards_disabled",
            "task_id": task_id,
        }


class InMemoryImCardAdapter:
    """A process-local card store: the test double for the seam.

    Cards live for the lifetime of the adapter instance (a real IM
    channel is out of scope for TH-5 — no SDK, no credentials). One
    open loop per kind means the card identity is the loop identity
    per human: the deterministic card id is ``imcard-{task}-{kind}-
    {human}``, so a repeated raise on the same open record refreshes
    the one card instead of opening a second, and a fresh raise after
    the loop closed (and its cards) opens a new card on the same
    identity.
    """

    name = "memory"

    def __init__(self) -> None:
        # (task_id, kind, human) -> card
        self._cards: dict[tuple[str, str, str], dict[str, Any]] = {}

    def cards(self, task_id: str) -> dict[str, dict[str, Any]]:
        """The task's cards (a shallow copy each), keyed by card id."""
        return {
            str(card.get("cardId") or ""): dict(card)
            for (task, _kind, _human), card in self._cards.items()
            if task == task_id
        }

    def raise_card(
        self, *, task_id: str, human: str, record: dict[str, Any]
    ) -> dict[str, Any]:
        kind = str(record.get("kind") or "")
        if record.get("resolved"):
            return {
                "opened": False,
                "reason": "already_resolved",
                "task_id": task_id,
                "human": human,
            }
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        card_id = f"imcard-{task_id}-{kind}-{human}"
        existing = self._cards.get((task_id, kind, human))
        if existing is not None and not existing.get("closed"):
            # Same open loop, same human: refresh in place (idempotent).
            existing.update(render_im_card(record))
            existing["refreshedAt"] = now
            return {"opened": True, "created": False, "cardId": card_id, "card": dict(existing)}
        card: dict[str, Any] = {
            "cardId": card_id,
            "task_id": task_id,
            "human": human,
            "closed": False,
            "openedAt": now,
        }
        card.update(render_im_card(record))
        self._cards[(task_id, kind, human)] = card
        return {"opened": True, "created": True, "cardId": card_id, "card": dict(card)}

    def close_cards(self, *, task_id: str) -> dict[str, Any]:
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        closed_ids: list[str] = []
        for (task, _kind, _human), card in self._cards.items():
            if task != task_id or card.get("closed"):
                continue
            card["closed"] = True
            card["closedAt"] = now
            closed_ids.append(str(card.get("cardId") or ""))
        return {"closed": len(closed_ids), "cardIds": closed_ids, "task_id": task_id}


def get_im_card_adapter() -> ImCardAdapter:
    """Resolve the active IM card channel (call-time).

    The default is the no-op channel (cards disabled — the pre-TH-5
    behaviour). Tests and a future IM integration replace it at this
    seam the way the room adapter seam (TH-3) is replaced.
    """
    return NoOpImCardAdapter()


# Monkeypatch-sensitive: register the real object so the call sites
# resolve it at call time against the bound server copy (a test patch
# of server.get_im_card_adapter stays visible there).
refs.define("get_im_card_adapter", get_im_card_adapter)


# Monkeypatch-sensitive: resolve the active card channel at call time.
_im_card_adapter = refs.proxy("get_im_card_adapter")


def _out_of_room_humans(notification: dict[str, Any]) -> list[str]:
    """The humans the room send could not reach (human_not_in_room gaps).

    Only that frozen gap reason opens a card: a human in the room stays
    on the Matrix path, and the other gap reasons (leader / room /
    env) say nothing about a reachable human.
    """
    humans: list[str] = []
    for gap in notification.get("gaps") or []:
        if not isinstance(gap, dict) or gap.get("reason") != "human_not_in_room":
            continue
        human = str(gap.get("recipient") or "").strip()
        if human and human not in humans:
            humans.append(human)
    return humans


def _im_card_notify_out_of_room_humans(
    task_id: str, record: dict[str, Any], notification: dict[str, Any]
) -> dict[str, Any]:
    """The TH-5 card path for one attention raise.

    One ``raise_card`` per human the room send reported as
    ``human_not_in_room``; the card renders from the S0 record fields.
    Best effort by contract: the per-human adapter result is surfaced
    verbatim and no card failure (or adapter exception) propagates
    into the attention flow — the Matrix send and its retry semantics
    are already final when this runs.
    """
    entries: list[dict[str, Any]] = []
    for human in _out_of_room_humans(notification):
        try:
            result = _im_card_adapter().raise_card(task_id=task_id, human=human, record=record)
        except Exception as exc:  # noqa: BLE001 — best-effort channel
            result = {"opened": False, "error": str(exc)[:300]}
        entry: dict[str, Any] = {"human": human, "opened": bool(result.get("opened"))}
        if result.get("cardId"):
            entry["cardId"] = result["cardId"]
        if result.get("reason"):
            entry["reason"] = result["reason"]
        if result.get("error"):
            entry["error"] = result["error"]
        entries.append(entry)
    return {"cards": entries}


def _close_task_cards(task_id: str) -> dict[str, Any]:
    """Close every open card for the task (a resolve on any side).

    Idempotent and best effort: a second close reports zero, and no
    card failure propagates into the resolve path.
    """
    try:
        return _im_card_adapter().close_cards(task_id=task_id)
    except Exception as exc:  # noqa: BLE001 — best-effort channel
        return {"closed": 0, "error": str(exc)[:300]}
