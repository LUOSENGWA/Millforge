"""MF-2 (G4): artifact indirect-injection recording + contract dual confirmation.

Two record-only mechanisms on the task meta. Neither changes any existing
state-transition semantics, adds a gate, or emits a signal:

1. ``input_anomalies[]`` — REDLINE S1 (artifact is data, not instruction).
   When the submitted artifacts (``result.md`` and the deliverables)
   contain indirect prompt-injection text, each finding is recorded as a
   text summary (the offending line, truncated) + source ref (the
   workspace-relative artifact path). The submission is NEVER blocked;
   the record stays queryable on the task meta and is mirrored to shared
   storage with it. Findings are merged across resubmissions (deduped by
   source/pattern/line/excerpt), so a recorded anomaly is never lost.

2. ``contract_confirmation`` — REDLINE S3 (contract dual confirmation).
   The provider (the submitting worker / remote-member) stamps one record
   on ``submit_task``; the consumer (the accepting leader) stamps one
   record on ``accept_task_result``. A single side alone is NOT
   confirmation: the derived status is ``confirmed`` only while both
   records are present.

Task meta fields (names chosen here, documented for the PR):
``input_anomalies`` — list of finding dicts; ``contract_confirmation`` —
``{provider: {actor, confirmed_at, submission_id},
   consumer: {actor, confirmed_at, node_status, accepted}}``. No other
meta field is touched.
"""

from __future__ import annotations

import re
from typing import Any

from mcp.artifact.publish import (
    TEXT_ARTIFACT_SAMPLE_BYTES,
    _artifact_is_text,
    _artifact_mimetype,
    _resolve_workspace_artifact_path,
)
from mcp.common.io import _utc_timestamp

ANOMALY_TYPE_INDIRECT_INJECTION = "indirect_injection"

# The excerpt is a text summary of the offending line (the record, not a
# redaction): short enough to stay readable in the task meta.
EXCERPT_MAX_CHARS = 200

# (name, compiled pattern) — indirect prompt-injection signatures, EN and
# their ZH twins. Conservative on purpose: this runs over every submitted
# artifact, and a false positive only costs one queryable record.
INJECTION_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "ignore_previous_instructions",
        re.compile(
            r"\b(?:ignore|disregard|forget)\s+(?:all\s+|any\s+|the\s+|your\s+|these\s+)*"
            r"(?:previous|prior|above|earlier|preceding|initial|original)\s+instructions\b"
            r"|忽略之前(?:的)?指令|忽略以上(?:的)?指令|忽略先前(?:的)?指令",
            re.IGNORECASE,
        ),
    ),
    (
        "persona_override",
        re.compile(
            r"\b(?:you are now|from now on,?\s+you are|you must now|act as if you are)\b"
            r"|你现在是|从现在起",
            re.IGNORECASE,
        ),
    ),
    (
        "hidden_from_user",
        re.compile(
            r"\bdo not (?:tell|inform|reveal to) the user\b"
            r"|\bwithout (?:telling|informing) the user\b"
            r"|不要告诉用户|别告诉用户",
            re.IGNORECASE,
        ),
    ),
    (
        "exfil_system_prompt",
        re.compile(
            r"\b(?:output|print|repeat|reveal|show|dump|echo)\b"
            r"(?:\s+\w+){0,3}\s+(?:the\s+)?system\s+prompt\b"
            r"|输出系统提示词|打印系统提示词|显示系统提示词",
            re.IGNORECASE,
        ),
    ),
]


def scan_text_for_injection(text: str) -> list[tuple[str, int, str]]:
    """(pattern_name, line_number, excerpt) findings for one text sample.

    Line numbers are 1-based; the excerpt is the full offending line
    (stripped, truncated to EXCERPT_MAX_CHARS) — the "text summary" half
    of the record.
    """
    findings: list[tuple[str, int, str]] = []
    for name, pattern in INJECTION_PATTERNS:
        for match in pattern.finditer(text):
            line_no = text.count("\n", 0, match.start()) + 1
            line_start = text.rfind("\n", 0, match.start()) + 1
            line_end = text.find("\n", match.end())
            if line_end == -1:
                line_end = len(text)
            findings.append(
                (name, line_no, text[line_start : line_end].strip()[:EXCERPT_MAX_CHARS])
            )
    findings.sort(key=lambda item: (item[1], item[0]))
    return findings


def scan_task_artifacts(
    arguments: dict[str, Any],
    task_id: str,
    deliverables: list[Any],
    actor: str,
) -> list[dict[str, Any]]:
    """Indirect-injection findings over the submitted artifacts
    (``result.md`` + deliverables), each as a record-ready dict.

    Reuses the artifact text predicates of the sensitive scan (same 256 KB
    sampling, same text/binary decision, same workspace-relative
    resolution under ``shared/tasks/<task_id>``). Record-only: an
    unresolvable, missing, or unreadable source is skipped, never raised.
    """
    expected_prefix = f"shared/tasks/{task_id}"
    sources = [f"{expected_prefix}/result.md"]
    for item in deliverables or []:
        source = str(item or "").strip()
        if source:
            sources.append(source)
    seen: set[tuple[str, str, int, str]] = set()
    records: list[dict[str, Any]] = []
    for source in sources:
        try:
            normalized, local_path = _resolve_workspace_artifact_path(
                arguments, source, expected_prefix
            )
        except ValueError:
            continue
        try:
            if not local_path.is_file():
                continue
            mimetype = _artifact_mimetype(local_path)
            if not _artifact_is_text(local_path, mimetype):
                continue
            sample = local_path.read_bytes()[:TEXT_ARTIFACT_SAMPLE_BYTES]
        except OSError:
            continue
        if b"\x00" in sample:
            continue
        for name, line_no, excerpt in scan_text_for_injection(
            sample.decode("utf-8", errors="replace")
        ):
            key = (normalized, name, line_no, excerpt)
            if key in seen:
                continue
            seen.add(key)
            records.append(
                {
                    "type": ANOMALY_TYPE_INDIRECT_INJECTION,
                    "source": normalized,
                    "pattern": name,
                    "line": line_no,
                    "excerpt": excerpt,
                    "recorded_at": _utc_timestamp(),
                    "recorded_by": actor,
                }
            )
    return records


def merge_input_anomalies(
    task: dict[str, Any], new_records: list[dict[str, Any]]
) -> bool:
    """Merge new findings into ``task["input_anomalies"]``, deduped by
    (source, pattern, line, excerpt). Returns True when anything was
    added (the caller decides whether a write is needed). The key is not
    created for a task that has no findings at all — the meta shape of a
    clean submission is unchanged.
    """
    existing = task.get("input_anomalies")
    if not isinstance(existing, list):
        existing = []
    seen = {
        (item.get("source"), item.get("pattern"), item.get("line"), item.get("excerpt"))
        for item in existing
        if isinstance(item, dict)
    }
    added = False
    for record in new_records:
        key = (
            record.get("source"),
            record.get("pattern"),
            record.get("line"),
            record.get("excerpt"),
        )
        if key in seen:
            continue
        seen.add(key)
        existing.append(record)
        added = True
    if added or "input_anomalies" in task:
        task["input_anomalies"] = existing
    return added


def _confirmation(task: dict[str, Any]) -> dict[str, Any]:
    cc = task.get("contract_confirmation")
    if not isinstance(cc, dict):
        cc = {}
        task["contract_confirmation"] = cc
    return cc


def stamp_provider_confirmation(
    task: dict[str, Any], actor: str, submission_id: str
) -> bool:
    """Provider side (submit_task): idempotent per submission identity —
    a resubmission of the same submission keeps the first stamp. Returns
    True when the meta changed.
    """
    cc = _confirmation(task)
    provider = cc.get("provider")
    if isinstance(provider, dict) and provider.get("submission_id") == submission_id:
        return False
    cc["provider"] = {
        "actor": actor,
        "confirmed_at": _utc_timestamp(),
        "submission_id": submission_id,
    }
    return True


def stamp_consumer_confirmation(
    task: dict[str, Any], actor: str, node_status: str, accepted: bool
) -> bool:
    """Consumer side (accept_task_result): one stamp, keep-first — a
    repaired re-accept does not overwrite the consumer record. Returns
    True when the meta changed.
    """
    cc = _confirmation(task)
    if isinstance(cc.get("consumer"), dict):
        return False
    cc["consumer"] = {
        "actor": actor,
        "confirmed_at": _utc_timestamp(),
        "node_status": node_status,
        "accepted": bool(accepted),
    }
    return True


def contract_confirmation_status(task: dict[str, Any]) -> str:
    """Derived dual-confirmation status: ``confirmed`` only while BOTH the
    provider and the consumer record are present — one side alone is
    never confirmation (S3).
    """
    cc = task.get("contract_confirmation") if isinstance(task, dict) else None
    if not isinstance(cc, dict):
        return "none"
    has_provider = isinstance(cc.get("provider"), dict)
    has_consumer = isinstance(cc.get("consumer"), dict)
    if has_provider and has_consumer:
        return "confirmed"
    if has_provider:
        return "provider_only"
    if has_consumer:
        return "consumer_only"
    return "none"
