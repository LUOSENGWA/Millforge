# decision_log (MF-1): append-only decision records with ref + sha256-8,
# three-layer verification, and dual-source comparison against the mirror
from __future__ import annotations

import json

from hashlib import sha256

from pathlib import Path

from typing import Any

# Cross-group imports are top-level absolutes (`common.*`) — see the note in
# transitions.py: mcp/ on sys.path makes the identity identical in both
# `import server` and `import mcp.server` modes.
from mcp.common import refs
from mcp.common.io import _utc_timestamp
from mcp.common.payload import _positive_int, _safe_id
from mcp.common.paths import _workspace_dir
from .transitions import _transition_actor

# The MinIO/shared mirror goes through the existing filesync client — the
# same local-write-then-best-effort-mirror-push pattern as the S2 signal
# events (lifecycle/signal_events.py). No new storage client.
_filesync = refs.proxy("_filesync")
_write_json = refs.proxy("_write_json")

# The entry digest is the first 8 hex chars of the sha256 over the entry's
# canonical JSON — every field except the digest itself, keys sorted, no
# whitespace — so an edit to any recorded field (or to the entry set) breaks
# the hash at verification time.
_DIGEST_HEX_CHARS = 8


def _entry_digest(entry: dict[str, Any]) -> str:
    body = {key: value for key, value in entry.items() if key != "sha256"}
    canonical = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return sha256(canonical.encode("utf-8")).hexdigest()[:_DIGEST_HEX_CHARS]


def _decision_log_path(workspace: Path, task_id: str, spawn: str) -> Path:
    return workspace / "shared" / "decisions" / task_id / f"{spawn}.json"


def _decision_log_relpath(task_id: str, spawn: str) -> str:
    return f"shared/decisions/{task_id}/{spawn}.json"


def _merged(arguments: dict[str, Any]) -> dict[str, Any]:
    """The decision payload: the `payload` object as the base, flat
    arguments filling the gaps (the same convention as the other tools)."""
    data = dict(arguments.get("payload")) if isinstance(arguments.get("payload"), dict) else {}
    for key in ("taskId", "task_id", "spawn", "decision", "attempt", "detail"):
        if data.get(key) is None and arguments.get(key) is not None:
            data[key] = arguments[key]
    return data


def _load_log(
    path: Path, task_id: str, spawn: str
) -> tuple[dict[str, Any] | None, list[dict[str, Any]], str | None]:
    """Read + shape-check an existing log file.

    Returns (log, entries, error): log is None when the file is absent.
    error is one of ``log_unreadable`` (missing-parse / wrong shape) or
    ``log_identity_mismatch`` (the file's own identity does not match the
    path it lives at) — in both cases the caller must refuse to write; a
    damaged log is never merged over.
    """
    if not path.exists():
        return None, [], None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None, [], "log_unreadable"
    if not isinstance(data, dict) or not isinstance(data.get("entries"), list):
        return None, [], "log_unreadable"
    if not all(isinstance(entry, dict) for entry in data["entries"]):
        return None, [], "log_unreadable"
    if str(data.get("task_id") or "") != task_id or str(data.get("spawn") or "") != spawn:
        return None, [], "log_identity_mismatch"
    return data, data["entries"], None


def _check_hash_layer(entries: list[dict[str, Any]]) -> tuple[bool, list[dict[str, Any]]]:
    """Layer 2: every entry's stored sha256-8 must equal the digest
    recomputed from its own recorded content."""
    bad: list[dict[str, Any]] = []
    for index, entry in enumerate(entries):
        stored = entry.get("sha256")
        computed = _entry_digest(entry)
        if not isinstance(stored, str) or stored != computed:
            bad.append({
                "index": index,
                "ref": str(entry.get("ref") or ""),
                "stored": stored,
                "expected": computed,
            })
    return (not bad), bad


def _check_chain_layer(entries: list[dict[str, Any]], task_id: str, spawn: str) -> tuple[bool, list[str]]:
    """Layer 3: the ref chain is continuous — the file's entry order is the
    sequence itself, attempts run 1..N without gaps or repeats, and every
    ref is exactly <taskId>/<spawn>/<attempt>."""
    problems: list[str] = []
    for index, entry in enumerate(entries):
        attempt = entry.get("attempt")
        if isinstance(attempt, bool) or not isinstance(attempt, int) or attempt != index + 1:
            problems.append(f"entry {index}: attempt {attempt!r} breaks the 1..N sequence")
            continue
        ref = entry.get("ref")
        expected_ref = f"{task_id}/{spawn}/{attempt}"
        if ref != expected_ref:
            problems.append(f"entry {index}: ref {ref!r} != {expected_ref!r}")
    return (not problems), problems


def _mirror_push(arguments: dict[str, Any], task_id: str, spawn: str) -> dict[str, Any]:
    """Best-effort single-file mirror push (warn-only: the local write
    already committed, the same policy as the S2 event mirror)."""
    try:
        result = _filesync({**arguments, "action": "push", "path": _decision_log_relpath(task_id, spawn)})
    except Exception as exc:
        return {"status": "failed", "warning": f"mirror push unavailable: {exc}"}
    if isinstance(result, dict) and result.get("ok"):
        return {"status": "pushed"}
    error = str((result or {}).get("error") or "mirror push failed")
    return {"status": "failed", "warning": error}


def record_decision(arguments: dict[str, Any]) -> dict[str, Any]:
    """Append one immutable entry to the decision log (MF-1).

    The log lives at shared/decisions/<taskId>/<spawn>.json (mirrored to
    the same relative path in shared storage). Each entry records its
    ``ref`` (taskId/spawn/attempt) plus a sha256-8 digest of its content.
    Append-only invariants, enforced here at write time:

    - a replay of an already-recorded ref (the same attempt) is rejected
      with the original digest — never overwritten;
    - an explicit attempt that is not the next free one is refused
      (``attempt_gap``), so the chain can never develop a hole;
    - a log whose stored entries no longer verify (tamper / damage) is
      never extended: repair it from the dual source first.

    The actor is the trusted runtime identity (``role:account``, the same
    mechanism as the task transition history) — never a payload field.
    """
    tool = "record_decision"
    base: dict[str, Any] = {"ok": True, "tool": tool}
    try:
        data = _merged(arguments)
        task_id = _safe_id(data.get("taskId") or data.get("task_id"), "taskId")
        spawn = _safe_id(data.get("spawn"), "spawn")
        decision = str(data.get("decision") or "").strip()
        if not decision:
            return {**base, "ok": False, "error": "decision is required"}
        detail = data.get("detail")
        if detail is not None and not isinstance(detail, dict):
            return {**base, "ok": False, "error": "detail must be an object"}
        attempt: int | None = None
        if data.get("attempt") is not None:
            attempt = _positive_int(data.get("attempt"), "attempt")
    except ValueError as exc:
        return {**base, "ok": False, "error": str(exc)}
    try:
        workspace = _workspace_dir(arguments)
    except ValueError as exc:
        return {**base, "ok": False, "error": str(exc)}

    path = _decision_log_path(workspace, task_id, spawn)
    _log, entries, load_error = _load_log(path, task_id, spawn)
    if load_error == "log_unreadable":
        return {
            **base, "ok": False, "reason": "log_unreadable",
            "error": "the existing decision log cannot be parsed; repair it from the shared-storage mirror before recording",
        }
    if load_error == "log_identity_mismatch":
        return {
            **base, "ok": False, "reason": "log_identity_mismatch",
            "error": "the existing decision log identifies a different task/spawn than its path; refusing to merge",
        }
    hash_ok, hash_bad = _check_hash_layer(entries)
    if not hash_ok:
        return {
            **base, "ok": False, "reason": "log_tampered",
            "bad_entries": hash_bad,
            "error": "the existing decision log failed hash verification; refusing to extend it",
        }
    chain_ok, chain_problems = _check_chain_layer(entries, task_id, spawn)
    if not chain_ok:
        return {
            **base, "ok": False, "reason": "log_chain_broken",
            "problems": chain_problems,
            "error": "the existing decision log has a broken ref chain; refusing to extend it",
        }

    next_attempt = len(entries) + 1
    if attempt is not None and attempt != next_attempt:
        if attempt <= len(entries):
            existing = entries[attempt - 1]
            return {
                **base, "ok": False, "reason": "duplicate_ref",
                "ref": f"{task_id}/{spawn}/{attempt}",
                "existing_sha256": existing.get("sha256"),
                "error": "append-only: this ref is already recorded; a replay is rejected, never overwritten",
            }
        return {
            **base, "ok": False, "reason": "attempt_gap",
            "expected_attempt": next_attempt,
            "error": "append-only: the ref chain must stay continuous; refusing to leave a gap",
        }
    if attempt is None:
        attempt = next_attempt

    entry_body: dict[str, Any] = {
        "ref": f"{task_id}/{spawn}/{attempt}",
        "attempt": attempt,
        "decision": decision,
        "actor": _transition_actor(arguments),
        "occurred_at": _utc_timestamp(),
    }
    if detail is not None:
        entry_body["detail"] = detail
    entry = {**entry_body, "sha256": _entry_digest(entry_body)}
    entries.append(entry)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        _write_json(path, {"task_id": task_id, "spawn": spawn, "entries": entries})
    except (OSError, TypeError, ValueError) as exc:
        return {
            **base, "ok": False, "retryable": True, "statePersisted": False,
            "error": f"could not persist the decision log: {exc}",
        }
    return {
        **base,
        "task_id": task_id,
        "spawn": spawn,
        "ref": entry["ref"],
        "attempt": attempt,
        "sha256": entry["sha256"],
        "entry": entry,
        "path": _decision_log_relpath(task_id, spawn),
        "entries": len(entries),
        "mirror": _mirror_push(arguments, task_id, spawn),
    }


def _remote_status(arguments: dict[str, Any], local_path: Path, task_id: str, spawn: str) -> dict[str, Any]:
    """Dual-source comparison: the local log object vs its shared-storage
    mirror, read through the existing filesync client (action=cat).

    match          — the mirror object is byte-identical to the local file
    mismatch       — the mirror object differs (divergence finding)
    missing        — the mirror object does not exist
    local_missing  — the local file is absent but the mirror object exists
    unavailable    — the mirror could not be read (storage not configured /
                     probe failed): reported with a warning, not a failure —
                     the same fail-open stance as the filesync push guard.
    """
    try:
        local_bytes: bytes | None = local_path.read_bytes()
    except OSError:
        local_bytes = None
    try:
        result = _filesync({**arguments, "action": "cat", "path": _decision_log_relpath(task_id, spawn)})
    except Exception as exc:
        return {"status": "unavailable", "warning": f"mirror probe unavailable: {exc}"}
    if not isinstance(result, dict):
        return {"status": "unavailable"}
    if result.get("ok") and isinstance(result.get("content"), str):
        if local_bytes is None:
            return {"status": "local_missing"}
        local_digest = sha256(local_bytes).hexdigest()
        remote_digest = sha256(result["content"].encode("utf-8")).hexdigest()
        return {"status": "match" if local_digest == remote_digest else "mismatch"}
    error = str(result.get("error") or "")
    if "does not exist" in error.lower():
        return {"status": "missing"}
    return {"status": "unavailable", "warning": error or "mirror probe failed"}


def _verify_one_spawn(
    arguments: dict[str, Any], decisions_dir: Path, task_id: str, spawn: str
) -> dict[str, Any]:
    path = decisions_dir / f"{spawn}.json"
    layers: dict[str, Any] = {"file": {"ok": False}, "hash": {"ok": False}, "chain": {"ok": False}}
    result: dict[str, Any] = {
        "spawn": spawn,
        "status": "ok",
        "entries": 0,
        "layers": layers,
    }
    if not path.exists():
        result["status"] = "missing"
        layers["file"] = {"ok": False, "problem": "log file does not exist"}
    else:
        _log, entries, load_error = _load_log(path, task_id, spawn)
        if load_error:
            result["status"] = "malformed"
            layers["file"] = {"ok": False, "problem": load_error}
        else:
            layers["file"] = {"ok": True}
            result["entries"] = len(entries)
            hash_ok, hash_bad = _check_hash_layer(entries)
            layers["hash"] = {"ok": hash_ok, **({"bad_entries": hash_bad} if hash_bad else {})}
            chain_ok, chain_problems = _check_chain_layer(entries, task_id, spawn)
            layers["chain"] = {"ok": chain_ok, **({"problems": chain_problems} if chain_problems else {})}
            if not hash_ok:
                result["status"] = "tampered"
            elif not chain_ok:
                result["status"] = "chain_broken"
    result["remote"] = _remote_status(arguments, path, task_id, spawn)
    return result


def verify_decision_log(arguments: dict[str, Any]) -> dict[str, Any]:
    """Verify the decision log for one task (MF-1).

    With ``spawn`` given, that one log is verified (a missing file is a
    finding); without it, every spawn log under shared/decisions/<taskId>/
    is verified (no logs at all is a valid, clean state).

    Three layers per log, plus the dual-source comparison of each log
    against its shared-storage mirror:

    1. file    — the log file exists and is well-formed (its identity
                 matches its path);
    2. hash    — every entry's stored sha256-8 equals the digest
                 recomputed from its recorded content;
    3. chain   — the ref chain is continuous (attempts 1..N in file
                 order, every ref exactly <taskId>/<spawn>/<attempt>).

    A reachable mirror must match: a missing or differing mirror object
    fails the verification; an unreachable mirror (storage not
    configured / probe failed) is reported, not a failure. Read-only:
    this tool never writes.
    """
    tool = "verify_decision_log"
    base: dict[str, Any] = {"ok": True, "tool": tool}
    try:
        data = _merged(arguments)
        task_id = _safe_id(data.get("taskId") or data.get("task_id"), "taskId")
        raw_spawn = data.get("spawn")
        spawn = _safe_id(raw_spawn, "spawn") if raw_spawn not in (None, "") else None
    except ValueError as exc:
        return {**base, "ok": False, "error": str(exc)}
    try:
        workspace = _workspace_dir(arguments)
    except ValueError as exc:
        return {**base, "ok": False, "error": str(exc)}

    decisions_dir = workspace / "shared" / "decisions" / task_id
    if spawn is None:
        targets = sorted(p.stem for p in decisions_dir.glob("*.json")) if decisions_dir.is_dir() else []
    else:
        targets = [spawn]
    results = [_verify_one_spawn(arguments, decisions_dir, task_id, target) for target in targets]
    ok = all(
        item["status"] == "ok" and item["remote"]["status"] in {"match", "unavailable"}
        for item in results
    )
    return {
        **base,
        "ok": ok,
        "task_id": task_id,
        "path": f"shared/decisions/{task_id}/",
        "spawns": results,
    }
