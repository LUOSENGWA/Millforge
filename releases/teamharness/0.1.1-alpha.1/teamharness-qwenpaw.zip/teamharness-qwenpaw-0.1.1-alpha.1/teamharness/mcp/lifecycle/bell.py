"""Bell (human-tier notification) priority — TH-22 (H4c / K5a).

A bell is the Manager's human-tier wake-up line: the fixed 3-line
format (09-GOVERNANCE §8.2 — MORE THAN 3 LINES IS A FORMAT VIOLATION,
plain words, no jargon), so the priority marker rides INSIDE the three
lines as a line-1 prefix, and ORDERING is the primary mechanism:
high-priority (human) bells are surfaced before the normal task queue.

This module is pure (no mcp/room imports) so it stays testable in
isolation and byte-identical across the source and bundle trees.
"""

from __future__ import annotations

BELL_PRIORITIES = ("normal", "high")
PRIORITY_RANK = {"high": 0, "normal": 1}
HIGH_PRIORITY_MARKER = "【高优】"


def normalize_bell_priority(value) -> str:
    """``value`` -> a known bell priority; unknown/None -> ``"normal"``.

    A degradation gate, not a validation gate: never raises (a bell
    that cannot be ranked is a normal bell, not an error).
    """
    if isinstance(value, str) and value in BELL_PRIORITIES:
        return value
    return "normal"


def bell_lines(
    what: str, outcome: str, pointer: str, *, priority: str = "normal"
) -> list[str]:
    """Render the fixed 3-line human-tier bell.

    ``what`` = ① what happened, ``outcome`` = ② the result,
    ``pointer`` = ③ the pointer.  Exactly 3 lines for every priority:
    a high-priority bell gets the :data:`HIGH_PRIORITY_MARKER` prefix
    on line 1 (the marker must stay inside the 3-line envelope).
    """
    first = str(what)
    if normalize_bell_priority(priority) == "high":
        first = f"{HIGH_PRIORITY_MARKER}{first}"
    return [first, str(outcome), str(pointer)]


def sort_bells(bells) -> list:
    """Stable high-first order: high-priority (human) bells before
    normal ones; input (arrival) order is kept within a rank.

    Entries are dicts; the rank comes from the optional ``priority``
    key (unknown/missing -> normal).  The entries are not copied or
    mutated.
    """
    return sorted(
        bells,
        key=lambda bell: PRIORITY_RANK[normalize_bell_priority(bell.get("priority"))],
    )
