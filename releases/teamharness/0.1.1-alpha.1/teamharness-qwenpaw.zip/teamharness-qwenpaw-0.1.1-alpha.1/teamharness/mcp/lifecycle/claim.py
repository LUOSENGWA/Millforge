# TH-14 (W3): task claim leases (claim / renew / release) — the
# coordination layer. contracts/claim-lease.json is the parameter
# authority (ttl 60..3600, default 300, lazy expiry, CAS mutex). The
# lease record lives in the task's meta.json under the `claim` field,
# and every mutation lands through the existing conditional-write
# machinery (_commit_task_guarded -> the controller's If-Match task-meta
# commit), so "exactly one claimant wins" follows from the CAS the
# endpoint already enforces — no lockfiles, no new storage backend, no
# controller change. The whole layer is switch-gated (default off):
# with the switch off, ack/submit keep the pre-lease behaviour and the
# claim actions report not_enabled.
from __future__ import annotations

import datetime

import json

import os

import time

from typing import Any

from mcp.common import refs
from mcp.common.config import _load_runtime_config, _section
from mcp.common.identity import _canonical_account
from mcp.common.payload import _first_text, _safe_id
from mcp.artifact.sync import _commit_task_guarded

# Claim parameter bounds — contracts/claim-lease.json (ttl_seconds
# min 60 / max 3600 / default 300).
CLAIM_TTL_MIN_SECONDS = 60
CLAIM_TTL_MAX_SECONDS = 3600
CLAIM_TTL_DEFAULT_SECONDS = 300
CLAIM_FIELD = "claim"

# Call-time lookup: the trusted caller identity (server-owned; test
# monkeypatches of server._runtime_identity stay visible here).
_runtime_identity = refs.proxy("_runtime_identity")


class LeaseRequiredError(Exception):
    """ack/submit without a live self-held lease (W3 rule 1).

    Deliberately NOT a ValueError subclass — the same pattern as
    ProtocolGuardError — so the taskflow tail maps it to a structured
    ``lease_required`` rejection instead of a bare error string.
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class _ClaimShortCircuit(Exception):
    """Carries a no-write outcome out of the _commit_task_guarded mutate
    callback (a claim that is already held, not held by us, absent, or
    expired) so that neither the local write nor the conditional commit
    happens. The callback re-runs on every 409 retry against the fresh
    base, so the evaluation is always made against the latest version.
    """

    def __init__(self, outcome: dict[str, Any]) -> None:
        super().__init__(json.dumps(outcome, sort_keys=True, ensure_ascii=False))
        self.outcome = outcome


def _claims_enforce_enabled() -> bool:
    """TH-14 (W3) claim/lease switch. The ``claims.enforce`` key of the
    TEAMHARNESS_RUNTIME_CONFIG (JSON or YAML) decides; the
    TEAMHARNESS_CLAIMS_ENFORCE environment variable overrides when set
    to a non-empty value. Default off: with the switch off ack/submit
    never demand a lease (the pre-lease behaviour, byte for byte) and
    the claim actions report ``not_enabled``.
    """
    override = os.getenv("TEAMHARNESS_CLAIMS_ENFORCE", "").strip().lower()
    if override:
        return override in {"1", "true", "yes", "on"}
    return bool(_section(_load_runtime_config(), "claims").get("enforce"))


def _now_seconds() -> float:
    """The wall clock the lease expiry compares against. A module-level
    seam so tests can pin the time (expiry is lazy — the only checks are
    the ones made at claim/renew/release/ack time). M0 is single-host,
    so the wall clock is comparable across claimant processes; cross-node
    clock skew is #1432 (a W3 non-goal).
    """
    return time.time()


def _iso_z(epoch_seconds: float) -> str:
    stamp = datetime.datetime.fromtimestamp(epoch_seconds, datetime.timezone.utc)
    return stamp.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _epoch_of(value: Any) -> float | None:
    try:
        text = str(value or "").strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        return datetime.datetime.fromisoformat(text).timestamp()
    except ValueError:
        return None


def _claim_of(task: dict[str, Any]) -> dict[str, Any] | None:
    """The task's claim record, or None when absent or malformed.

    A malformed record (no owner, no parseable expires_at) counts as NO
    claim: a broken record must not wedge the task forever — the next
    claimant simply takes it over.
    """
    claim = task.get(CLAIM_FIELD)
    if not isinstance(claim, dict):
        return None
    if not str(claim.get("owner") or "").strip():
        return None
    if _epoch_of(claim.get("expires_at")) is None:
        return None
    return claim


def _claim_is_live(claim: dict[str, Any], now_seconds: float) -> bool:
    # W3: now >= expires_at is treated as no lease (lazy expiry — there
    # is no background reaper).
    expires_at = _epoch_of(claim.get("expires_at"))
    return expires_at is not None and now_seconds < expires_at


def _owner_account(arguments: dict[str, Any]) -> str:
    """The caller's lease account.

    The trusted runtime identity wins when the runtime knows it (never
    overridable by a payload field — the #1467 round 6 discipline: a
    lease is an authorization property, so one member must never be able
    to claim under another member's name and block them). In local /
    test runs without a runtime identity, the payload owner / account_id
    carries the account (provenance fallback, the same order as
    _transition_actor).
    """
    account = _runtime_identity()
    if account:
        return str(account).strip()
    payload = arguments.get("payload") if isinstance(arguments.get("payload"), dict) else {}
    return _first_text(
        payload.get("owner"),
        arguments.get("owner"),
        arguments.get("account_id"),
        arguments.get("accountId"),
        "default",
    )


def _merged(arguments: dict[str, Any]) -> dict[str, Any]:
    """The claim payload: the `payload` object as the base, flat
    arguments filling the gaps (the same convention as the other tools).
    Note: the claim owner is NOT taken from here — it is the caller's
    identity (see _owner_account)."""
    data = dict(arguments.get("payload")) if isinstance(arguments.get("payload"), dict) else {}
    for key in ("taskId", "task_id", "ttl", "ttlSeconds", "ttl_seconds"):
        if data.get(key) is None and arguments.get(key) is not None:
            data[key] = arguments[key]
    return data


def _validate_ttl(value: Any) -> int:
    try:
        ttl = int(value)
    except (TypeError, ValueError):
        raise ValueError(
            f"ttl must be an integer of {CLAIM_TTL_MIN_SECONDS}..{CLAIM_TTL_MAX_SECONDS} seconds"
        ) from None
    if not CLAIM_TTL_MIN_SECONDS <= ttl <= CLAIM_TTL_MAX_SECONDS:
        raise ValueError(
            f"ttl must be within {CLAIM_TTL_MIN_SECONDS}..{CLAIM_TTL_MAX_SECONDS} seconds"
        )
    return ttl


def _ttl_of(data: dict[str, Any]) -> int:
    for key in ("ttl", "ttlSeconds", "ttl_seconds"):
        if data.get(key) is not None:
            return _validate_ttl(data[key])
    return CLAIM_TTL_DEFAULT_SECONDS


def _not_enabled(tool: str) -> dict[str, Any]:
    return {
        "ok": False,
        "tool": tool,
        "error_code": "not_enabled",
        "message": (
            "the claim/lease layer is off (TEAMHARNESS_CLAIMS_ENFORCE / "
            "claims.enforce); turn it on to use claim/renew/release"
        ),
    }


def _reject(tool: str, code: str, message: str) -> dict[str, Any]:
    return {"ok": False, "tool": tool, "error_code": code, "message": message}


def _ok(tool: str, task_id: str, claim: dict[str, Any], **extra: Any) -> dict[str, Any]:
    result = {"ok": True, "tool": tool, "taskId": task_id, "claim": dict(claim)}
    result.update(extra)
    return result


def _task_error(tool: str, exc: ValueError) -> dict[str, Any]:
    message = str(exc)
    if "task not found" in message:
        return _reject(tool, "unknown_task", message)
    return {"ok": False, "tool": tool, "error": message}


def claim_task(arguments: dict[str, Any]) -> dict[str, Any]:
    """Atomically take the task's lease — exactly one claimant wins.

    A live claim by another member is rejected (already_claimed); a live
    claim by this member is an idempotent no-op (no expiry bump); an
    absent or EXPIRED claim is (re-)taken — expiry makes the task
    claimable again by anyone. The winner's record: {owner,
    ttl_seconds, claimed_at, expires_at}.
    """
    tool = "claim_task"
    if not _claims_enforce_enabled():
        return _not_enabled(tool)
    data = _merged(arguments)
    task_id = _safe_id(_first_text(data.get("taskId"), data.get("task_id")), "taskId")
    owner = _owner_account(arguments)
    try:
        ttl = _ttl_of(data)
    except ValueError as exc:
        return _reject(tool, "invalid_ttl", str(exc))
    now = _now_seconds()
    state: dict[str, bool] = {"taken_over": False}

    def apply_claim(task: dict[str, Any]) -> dict[str, Any]:
        existing = _claim_of(task)
        if existing is not None and _claim_is_live(existing, now):
            if _canonical_account(existing["owner"]) == _canonical_account(owner):
                # Idempotent re-claim by the same holder: no write, no
                # expiry bump.
                raise _ClaimShortCircuit(
                    _ok(tool, task_id, existing, already_held=True)
                )
            raise _ClaimShortCircuit(
                _reject(
                    tool,
                    "already_claimed",
                    f"task {task_id} is claimed by {existing['owner']} until "
                    f"{existing['expires_at']}",
                )
            )
        if existing is not None:
            state["taken_over"] = True  # an expired record is replaced
        claim = {
            "owner": owner,
            "ttl_seconds": ttl,
            "claimed_at": _iso_z(now),
            "expires_at": _iso_z(now + ttl),
        }
        task[CLAIM_FIELD] = claim
        return claim

    try:
        _task, claim, _committed = _commit_task_guarded(
            arguments, task_id, apply_claim, action=tool
        )
    except _ClaimShortCircuit as exc:
        return exc.outcome
    except ValueError as exc:
        return _task_error(tool, exc)
    return _ok(tool, task_id, claim, taken_over=state["taken_over"])


def renew_claim(arguments: dict[str, Any]) -> dict[str, Any]:
    """Extend the caller's OWN lease: expires_at slides to now + ttl.

    Holder-only (not_holder otherwise). A claim that is absent is
    no_claim; one that already expired is claim_expired — renew never
    takes over, the claim must be re-acquired with claim_task.
    """
    tool = "renew_claim"
    if not _claims_enforce_enabled():
        return _not_enabled(tool)
    data = _merged(arguments)
    task_id = _safe_id(_first_text(data.get("taskId"), data.get("task_id")), "taskId")
    owner = _owner_account(arguments)
    try:
        ttl = _ttl_of(data)
    except ValueError as exc:
        return _reject(tool, "invalid_ttl", str(exc))
    now = _now_seconds()

    def apply_renew(task: dict[str, Any]) -> dict[str, Any]:
        existing = _claim_of(task)
        if existing is None:
            raise _ClaimShortCircuit(
                _reject(tool, "no_claim", f"task {task_id} has no claim; claim_task first")
            )
        if not _claim_is_live(existing, now):
            raise _ClaimShortCircuit(
                _reject(
                    tool,
                    "claim_expired",
                    f"task {task_id}'s claim expired at {existing['expires_at']}; "
                    "claim_task again",
                )
            )
        if _canonical_account(existing["owner"]) != _canonical_account(owner):
            raise _ClaimShortCircuit(
                _reject(
                    tool,
                    "not_holder",
                    f"task {task_id} is claimed by {existing['owner']}, not by this member",
                )
            )
        existing["ttl_seconds"] = ttl
        existing["renewed_at"] = _iso_z(now)
        existing["expires_at"] = _iso_z(now + ttl)
        return existing

    try:
        _task, claim, _committed = _commit_task_guarded(
            arguments, task_id, apply_renew, action=tool
        )
    except _ClaimShortCircuit as exc:
        return exc.outcome
    except ValueError as exc:
        return _task_error(tool, exc)
    return _ok(tool, task_id, claim, renewed=True)


def release_claim(arguments: dict[str, Any]) -> dict[str, Any]:
    """Give up the caller's OWN lease (holder-only for a live claim).

    Releasing when no live claim exists is an idempotent no-op
    (released: False) — a retry after the lease already expired must not
    error.
    """
    tool = "release_claim"
    if not _claims_enforce_enabled():
        return _not_enabled(tool)
    data = _merged(arguments)
    task_id = _safe_id(_first_text(data.get("taskId"), data.get("task_id")), "taskId")
    owner = _owner_account(arguments)
    now = _now_seconds()

    def apply_release(task: dict[str, Any]) -> None:
        existing = _claim_of(task)
        if existing is None or not _claim_is_live(existing, now):
            raise _ClaimShortCircuit(
                {
                    "ok": True,
                    "tool": tool,
                    "taskId": task_id,
                    "released": False,
                    "note": "no live claim to release",
                }
            )
        if _canonical_account(existing["owner"]) != _canonical_account(owner):
            raise _ClaimShortCircuit(
                _reject(
                    tool,
                    "not_holder",
                    f"task {task_id} is claimed by {existing['owner']}, not by this member",
                )
            )
        task.pop(CLAIM_FIELD, None)

    try:
        _task, _result, _committed = _commit_task_guarded(
            arguments, task_id, apply_release, action=tool
        )
    except _ClaimShortCircuit as exc:
        return exc.outcome
    except ValueError as exc:
        return _task_error(tool, exc)
    return {"ok": True, "tool": tool, "taskId": task_id, "released": True}


def _require_lease(
    arguments: dict[str, Any], task: dict[str, Any], task_id: str, action: str
) -> None:
    """W3 rule 1: with the claim switch on, ack_task / submit_task run
    only when the CALLER holds a live lease on the task. Off, this is a
    no-op — the pre-lease behaviour, byte for byte. Fail closed: an
    unknown caller identity never holds a lease.
    """
    if not _claims_enforce_enabled():
        return
    caller = _canonical_account(_owner_account(arguments))
    claim = _claim_of(task)
    if claim is not None and caller and _claim_is_live(claim, _now_seconds()):
        if _canonical_account(claim["owner"]) == caller:
            return
        raise LeaseRequiredError(
            f"{action} requires a lease held by this member: task {task_id} is "
            f"claimed by {claim['owner']} until {claim['expires_at']} (renew_claim "
            "it first)"
        )
    raise LeaseRequiredError(
        f"{action} requires a lease held by this member: task {task_id} has no "
        "live claim (claim_task it first)"
    )
