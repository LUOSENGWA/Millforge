# TH-16: wait_for_change — bounded event-wake primitive (执行册 §2.1 H5)
from __future__ import annotations

import ctypes

import json

import os

import select

import struct

import sys

import time

from pathlib import Path

from typing import Any

# Cross-group imports are top-level absolutes (see lifecycle/transitions.py
# note): mcp/ on sys.path keeps one module identity in both load modes.
from mcp.common import refs
from mcp.common.config import _runtime_team_name
from mcp.common.constants import TERMINAL_TASK_STATUSES, TRANSITIONS
from mcp.common.paths import _workspace_dir
from mcp.lifecycle.signal_events import SIGNAL_CONTRACT_PATH

# The mirror refresh shells out to the same storage sync as every other
# read tool (pull-then-read); the proxy keeps a test patch of
# server._filesync visible at this call site.
_filesync = refs.proxy("_filesync")


# ---------------------------------------------------------------------------
# wait_for_change — selector semantics (minimum contract, TH-16).
#
# wait_for_change(selector, deadline, action) blocks the CALLING runtime
# for at most ``deadline`` seconds (bounded; default 60, max 3600) until a
# selector-matching change lands in the LOCAL mirror, then returns. This is
# the C-5 "查一次 + 有界等待 + 信号唤醒" primitive: a Leader may replace a
# sleep-polling loop with one authoritative check (any pull-then-read tool)
# followed by a bounded wait; the wait wakes on inotify events — it never
# polls and never sleeps its way to a result. The same primitive is shared
# by the later kick/loop-runner waits (TH-17 and after).
#
# Selector facets (each optional; at least one required):
#
# - ``taskIds`` (alias ``taskId``): the tasks to watch (safe task ids
#   under shared/tasks/{id}).
# - ``projectIds`` (alias ``projectId``): project SCOPE — expanded at
#   snapshot time to the project's task ids (meta ``tasks[].task_id`` +
#   ``loop.tasks[].task_id``) and re-expanded on every rescan (a task
#   planned during the wait joins the scope). A project id is scope, not a
#   target: the project meta status is reported (``projectStates``) but
#   never satisfies by itself.
# - ``statuses`` (alias ``status``): TARGET task statuses from the closed
#   nine-state task vocabulary (planned / prepared / assigned /
#   in_progress / submitted / completed / revision / blocked / cancelled).
# - ``eventTypes`` (alias ``eventType``): TARGET S2 signal event types from
#   the CLOSED contract vocabulary (contracts/signal-mapping.json
#   ``event_type`` set — SIG-COMPLETE / SIG-DECISION / SIG-VERDICT /
#   SIG-ATTENTION / SIG-MISMATCH / SIG-CONTRACT / SIG-ARTIFACT). The
#   vocabulary is read from the contract at call time; an unreadable
#   contract fails closed (every value is unknown, TH-23 policy).
# - ``team``: the event stream to watch (default: the current runtime
#   team, ``global`` when unset).
#
# Scoping: a selector naming no taskIds/projectIds is TEAM-WIDE — every
# task directory under shared/tasks/ is in scope (status facet), and every
# event of the team's stream counts (event facet). Scoping filters apply
# per facet; an event with a task_id outside an explicit scope never
# matches.
#
# Satisfaction (checked at snapshot, after each inotify wake, and once
# more at the deadline):
#
# - ``statuses`` facet: any in-scope task currently in a target status.
# - ``eventTypes`` facet: any event NEW since the snapshot whose type is in
#   the target set and whose task is in scope.
# - Both facets: either satisfies; the result names the facet that did
#   (``satisfiedBy``) and carries the triggering event (``event``, null on
#   a status satisfaction).
# - Change-only form (scope facets but neither ``statuses`` nor
#   ``eventTypes``): any in-scope task whose status DIFFERS from its
#   snapshot value, or any new event for an in-scope task.
#
# Visibility model (documented, not enforced): the wait observes the LOCAL
# mirror only. It performs one best-effort mirror pull of the watched
# streams (events dir; each explicitly watched task/project dir) before
# snapshotting — the "查一次" of the pattern — reported as ``refresh``
# (ok / failed / skipped); a failed refresh degrades to local-mirror-only
# and is surfaced, never hidden. (A team-wide selector pulls the events
# stream only; per-task freshness for its status facet rides on the other
# tools' pull-then-read calls.) Remote-side changes made after the
# snapshot become visible only when a pull lands (the runtime push loop is
# outbound-only), so the operating pattern is: wait with a bounded
# deadline; on ``timeout`` re-evaluate (a fresh wait re-pulls) or escalate
# — never retry unboundedly.
#
# Guarantees: bounded by ``deadline`` (a timeout is a first-class result —
# ``status: "timeout"`` — not an error and never an indefinite hang);
# read-only — the tool never writes task/project meta, appends no
# transition history, emits no events, and never executes or mutates the
# caller's ``action`` (it only reports whether the target state was
# reached).
# ---------------------------------------------------------------------------

DEFAULT_DEADLINE_SECONDS = 60.0
MAX_DEADLINE_SECONDS = 3600.0
MIN_DEADLINE_SECONDS = 1

# inotify event masks (linux/inotify.h). The watch mask is a superset of
# what matters: the watcher uses records only as wake hints and re-scans
# the filesystem as truth, so a gap in the mask set costs latency at
# worst — the deadline's final rescan still reports the true state.
IN_CREATE = 0x00000100
IN_MODIFY = 0x00000002
IN_CLOSE_WRITE = 0x00000008
IN_MOVED_TO = 0x00000080
IN_DELETE = 0x00000200
IN_DELETE_SELF = 0x04000000
IN_IGNORED = 0x00000001
IN_Q_OVERFLOW = 0x00004000
_WAIT_MASK = IN_CREATE | IN_MODIFY | IN_CLOSE_WRITE | IN_MOVED_TO | IN_DELETE

_SELECTOR_FIELDS = (
    "team", "taskIds", "taskId", "projectIds", "projectId",
    "status", "statuses", "eventType", "eventTypes",
)

# The closed nine-state task vocabulary: TRANSITIONS keys plus targets plus
# the terminal set (single source of truth: contracts/task-transitions.json
# via the constants mirror).
TASK_STATUS_VOCABULARY = frozenset(
    set(TRANSITIONS)
    | {status for targets in TRANSITIONS.values() for status in targets}
    | TERMINAL_TASK_STATUSES
)


def _contract_event_types() -> tuple[str, ...]:
    """The closed S2 event-type vocabulary from the contract fixture.

    Single source of truth: contracts/signal-mapping.json (the same file
    the Go emitter table is cross-checked against). An empty tuple when
    the fixture is unreadable — the selector then reports every value as
    unknown rather than inventing a vocabulary (TH-23 policy).
    """
    try:
        contract = json.loads(SIGNAL_CONTRACT_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ()
    types: list[str] = []
    for row in contract.get("events") or []:
        if not isinstance(row, dict):
            continue
        event_type = row.get("event_type")
        if isinstance(event_type, str) and event_type and event_type not in types:
            types.append(event_type)
    return tuple(types)


def _as_id_list(value: Any, field: str) -> list[str]:
    """string | list[string-ish] -> de-duplicated non-empty strings."""
    if value is None:
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        raise ValueError(f"{field} must be a string or a list of strings")
    items: list[str] = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, (str, int, float)):
            raise ValueError(f"{field} entries must be strings")
        text = str(item).strip()
        if text and text not in items:
            items.append(text)
    return items


def _parse_deadline(value: Any) -> float | None:
    """deadline seconds: a finite number in [1, 3600]; None when invalid."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    seconds = float(value)
    if seconds != seconds or seconds in (float("inf"), float("-inf")):
        return None
    if not (MIN_DEADLINE_SECONDS <= seconds <= MAX_DEADLINE_SECONDS):
        return None
    return seconds


def _task_meta_path(workspace: Path, task_id: str) -> Path:
    return workspace / "shared" / "tasks" / task_id / "meta.json"


def _project_meta_path(workspace: Path, project_id: str) -> Path:
    return workspace / "shared" / "projects" / project_id / "meta.json"


def _read_status(meta_path: Path) -> str | None:
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(meta, dict):
        return None
    status = str(meta.get("status") or "").strip()
    return status or None


def _project_task_ids(workspace: Path, project_id: str) -> list[str]:
    """The project's task ids from its local mirror meta (tasks[] +
    loop.tasks[].task_id). Empty when the meta is absent or unreadable —
    the project then contributes no scope (reported as a warning)."""
    try:
        project = json.loads(_project_meta_path(workspace, project_id).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(project, dict):
        return []
    ids: list[str] = []
    nodes = project.get("tasks")
    if isinstance(nodes, list):
        for node in nodes:
            if isinstance(node, dict):
                task_id = str(node.get("task_id") or "").strip()
                if task_id and task_id not in ids:
                    ids.append(task_id)
    loop = project.get("loop")
    if isinstance(loop, dict):
        loop_tasks = loop.get("tasks")
        if isinstance(loop_tasks, list):
            for node in loop_tasks:
                if isinstance(node, dict):
                    task_id = str(node.get("task_id") or "").strip()
                    if task_id and task_id not in ids:
                        ids.append(task_id)
    return ids


def _events_dir(workspace: Path, team: str) -> Path:
    return workspace / "shared" / "events" / team


def _known_event_ids(events_dir: Path) -> set[str]:
    """Event identities from the mirror directory listing.

    The S2 on-disk convention is ``{event_id}.json`` (the filename IS the
    event id — see signal_events._emit_signal_event), so the id set comes
    free of reading file contents; only candidate matches are read in
    full. Non-.json entries are ignored.
    """
    if not events_dir.is_dir():
        return set()
    ids: set[str] = set()
    for path in events_dir.iterdir():
        if path.is_file() and path.suffix == ".json":
            ids.add(path.stem)
    return ids


def _new_events(
    events_dir: Path,
    seen: set[str],
    task_scope: frozenset[str],
    event_types: frozenset[str],
    scope_filter: bool,
) -> list[dict[str, Any]]:
    """Events that landed after the snapshot, filtered by type and scope.

    Returns the matching events in (occurred_at, event_id) order. A file
    that fails to parse is skipped (the same tolerance as list_events).
    ``scope_filter`` is True only for an explicit task/project scope; a
    team-wide selector counts every event of the team's stream.
    """
    found: list[dict[str, Any]] = []
    for path in sorted(events_dir.glob("*.json")):
        if path.stem in seen:
            continue
        try:
            event = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(event, dict):
            continue
        event_type = str(event.get("event_type") or "")
        if event_types and event_type not in event_types:
            continue
        if scope_filter and str(event.get("task_id") or "") not in task_scope:
            continue
        found.append(event)
    found.sort(key=lambda e: (str(e.get("occurred_at") or ""), str(e.get("event_id") or "")))
    return found


def _evaluate(
    *,
    task_scope: frozenset[str],
    target_statuses: frozenset[str],
    target_event_types: frozenset[str],
    change_only: bool,
    snapshot_task_states: dict[str, str | None],
    task_states: dict[str, str | None],
    fresh_events: list[dict[str, Any]],
) -> tuple[str | None, dict[str, Any] | None]:
    """The satisfaction predicate. Returns (satisfiedBy, triggering event).

    The status facet is evaluated first; with both facets present either
    may satisfy (the event facet then does not report). The event facet
    applies only when the caller enabled it — an explicit eventTypes list
    or the change-only form — so a statuses-only wait is never satisfied
    by an unrelated event landing in the stream.
    """
    if target_statuses:
        for task_id in sorted(task_scope):
            if task_states.get(task_id) in target_statuses:
                return "status", None
    elif change_only:
        for task_id in sorted(task_scope):
            status = task_states.get(task_id)
            if status is not None and status != snapshot_task_states.get(task_id):
                return "status", None
    if fresh_events and (change_only or target_event_types):
        return "event", fresh_events[0]
    return None, None


def _refresh_mirror(
    arguments: dict[str, Any], team: str, task_ids: list[str], project_ids: list[str]
) -> str:
    """One best-effort pull of the watched streams before snapshotting.

    Read-only by construction (filesync pull). Failures are warn-and-
    continue, reported via the returned status ("ok" / "failed" /
    "skipped") — the wait proceeds against the local mirror either way.
    """
    paths = [f"shared/events/{team}"]
    paths.extend(f"shared/tasks/{task_id}" for task_id in task_ids)
    paths.extend(f"shared/projects/{project_id}" for project_id in project_ids)
    if not paths:
        return "skipped"
    ok = True
    for path in paths:
        result = _filesync({**arguments, "action": "pull", "path": path})
        if not (isinstance(result, dict) and result.get("ok")):
            ok = False
    return "ok" if ok else "failed"


# ---------------------------------------------------------------------------
# inotify watcher (Linux only, stdlib + libc only).
# ---------------------------------------------------------------------------


class _InotifyWatcher:
    """One inotify instance for one wait.

    Every wait opens its own instance fd, so concurrent waits on the same
    directories coexist (inotify delivers to every watcher). Records are
    consumed only as wake hints: after each wake the caller re-arms any
    missing watch and re-scans the filesystem, which is the truth. A lost
    or missed record therefore costs latency, never correctness — the
    deadline's final rescan always reports the true state.
    """

    def __init__(self) -> None:
        self._libc = ctypes.CDLL(None, use_errno=True)
        fd = self._libc.inotify_init()
        if fd < 0:
            errno = ctypes.get_errno()
            raise OSError(errno, os.strerror(errno) or "inotify_init failed")
        self._fd = fd
        self._watches: dict[str, int] = {}

    def add(self, path: Path) -> bool:
        key = str(path)
        if key in self._watches:
            return True
        try:
            wd = self._libc.inotify_add_watch(
                self._fd, os.fsencode(path), ctypes.c_uint32(_WAIT_MASK)
            )
        except (OSError, ValueError):
            return False
        if wd < 0:
            return False
        self._watches[key] = wd
        return True

    def poll(self, timeout: float) -> None:
        select.select([self._fd], [], [], max(0.0, timeout))

    def drain(self) -> int:
        """Consume all pending records; returns their count (capped)."""
        count = 0
        for _ in range(256):
            ready, _, _ = select.select([self._fd], [], [], 0)
            if not ready:
                break
            try:
                data = os.read(self._fd, 65536)
            except OSError:
                break
            if not data:
                break
            count += _count_inotify_records(data)
            if count > 100000:
                break
        return count

    def close(self) -> None:
        fd, self._fd = self._fd, -1
        self._watches.clear()
        if fd >= 0:
            try:
                os.close(fd)
            except OSError:
                pass


def _count_inotify_records(data: bytes) -> int:
    """Decode inotify_event framing (wd/mask/cookie/len + padded name).

    Only the count matters: the kernel pads each record to an 8-byte
    boundary, so the next offset is 16 + (len + 7) & ~7.
    """
    count = 0
    offset = 0
    size = len(data)
    while offset + 16 <= size:
        _wd, _mask, _cookie, length = struct.unpack_from("iIII", data, offset)
        offset += 16 + ((length + 7) & ~7)
        count += 1
    return count


def _inotify_available() -> bool:
    try:
        watcher = _InotifyWatcher()
    except (OSError, AttributeError, ValueError):
        return False
    watcher.close()
    return True


def _arm_watches(
    watcher: _InotifyWatcher,
    workspace: Path,
    team: str,
    events_dir: Path,
    tasks_root: Path,
    scope: list[str],
    project_ids: list[str],
) -> None:
    """(Re)arm every watch that can be armed.

    Missing directories are skipped this pass: the parent watches (events
    dir, tasks root, project dirs) catch their creation, and the next
    rescan re-arms.
    """
    watcher.add(events_dir)
    watcher.add(tasks_root)
    for task_id in scope:
        task_dir = tasks_root / task_id
        if task_dir.is_dir():
            watcher.add(task_dir)
    for project_id in project_ids:
        project_dir = workspace / "shared" / "projects" / project_id
        if project_dir.is_dir():
            watcher.add(project_dir)


def _scope_for_rescan(task_ids: list[str], project_ids: list[str], workspace: Path) -> list[str]:
    """The current task scope: explicit taskIds plus the (re-)expanded
    project task ids, de-duplicated in selection order. A selector naming
    neither is team-wide: every task directory under shared/tasks/."""
    if not task_ids and not project_ids:
        tasks_root = workspace / "shared" / "tasks"
        if tasks_root.is_dir():
            return [d.name for d in sorted(tasks_root.iterdir()) if d.is_dir()]
        return []
    scope: list[str] = list(task_ids)
    for project_id in project_ids:
        for task_id in _project_task_ids(workspace, project_id):
            if task_id not in scope:
                scope.append(task_id)
    return scope


def _task_states(workspace: Path, scope: list[str]) -> dict[str, str | None]:
    return {task_id: _read_status(_task_meta_path(workspace, task_id)) for task_id in scope}


def _project_states(workspace: Path, project_ids: list[str]) -> dict[str, str | None]:
    return {
        project_id: _read_status(_project_meta_path(workspace, project_id))
        for project_id in project_ids
    }


# ---------------------------------------------------------------------------
# Tool entry point.
# ---------------------------------------------------------------------------


def wait_for_change(arguments: dict[str, Any]) -> dict[str, Any]:
    """Bounded event-wake wait (TH-16). See the module docstring for the
    selector semantics, visibility model, and guarantees."""
    args = dict(arguments or {})
    base: dict[str, Any] = {"ok": True, "tool": "wait_for_change"}
    workspace = _workspace_dir(args)

    deadline = _parse_deadline(args.get("deadline", DEFAULT_DEADLINE_SECONDS))
    if deadline is None:
        return {
            **base,
            "ok": False,
            "error": "invalid_deadline",
            "message": (
                f"deadline must be a finite number of seconds between "
                f"{MIN_DEADLINE_SECONDS} and {MAX_DEADLINE_SECONDS:.0f} "
                f"(default {DEFAULT_DEADLINE_SECONDS:.0f})"
            ),
        }

    action = args.get("action")
    if action is not None and not isinstance(action, str):
        return {
            **base,
            "ok": False,
            "error": "invalid_action",
            "message": (
                "action must be a string (an echo label only; this tool "
                "never executes it)"
            ),
        }

    selector_raw = args.get("selector", {})
    if not isinstance(selector_raw, dict):
        return {
            **base,
            "ok": False,
            "error": "invalid_selector",
            "message": (
                "selector must be an object with taskIds / projectIds / "
                "statuses / eventTypes / team facets"
            ),
        }
    unknown_fields = sorted(set(selector_raw) - set(_SELECTOR_FIELDS))
    if unknown_fields:
        return {
            **base,
            "ok": False,
            "error": "invalid_selector",
            "message": f"unknown selector field(s): {', '.join(unknown_fields)}",
        }
    try:
        task_ids = _as_id_list(
            selector_raw["taskIds"] if "taskIds" in selector_raw else selector_raw.get("taskId"),
            "taskIds",
        )
        project_ids = _as_id_list(
            selector_raw["projectIds"] if "projectIds" in selector_raw else selector_raw.get("projectId"),
            "projectIds",
        )
        target_statuses_raw = _as_id_list(
            selector_raw["statuses"] if "statuses" in selector_raw else selector_raw.get("status"),
            "statuses",
        )
        target_event_types_raw = _as_id_list(
            selector_raw["eventTypes"]
            if "eventTypes" in selector_raw
            else selector_raw.get("eventType"),
            "eventTypes",
        )
    except ValueError as exc:
        return {
            **base,
            "ok": False,
            "error": "invalid_selector",
            "message": str(exc),
        }

    if not (task_ids or project_ids or target_statuses_raw or target_event_types_raw):
        return {
            **base,
            "ok": False,
            "error": "invalid_selector",
            "message": (
                "selector needs at least one facet: taskIds / projectIds / "
                "statuses / eventTypes (team alone is a stream, not a facet)"
            ),
        }

    bad_statuses = [s for s in target_statuses_raw if s not in TASK_STATUS_VOCABULARY]
    if bad_statuses:
        return {
            **base,
            "ok": False,
            "error": "invalid_selector",
            "message": (
                f"unknown status(es): {', '.join(bad_statuses)}; the task "
                f"status vocabulary is closed: {', '.join(sorted(TASK_STATUS_VOCABULARY))}"
            ),
        }
    contract_types = _contract_event_types()
    bad_event_types = [t for t in target_event_types_raw if t not in contract_types]
    if bad_event_types:
        return {
            **base,
            "ok": False,
            "error": "invalid_selector",
            "message": (
                f"unknown event type(s): {', '.join(bad_event_types)}; the "
                f"contract vocabulary is closed: "
                + (", ".join(contract_types) if contract_types else "(contract unreadable — fail closed)")
            ),
        }

    team = str(selector_raw.get("team") or _runtime_team_name() or "").strip() or "global"
    change_only = not target_statuses_raw and not target_event_types_raw
    scope_filter = bool(task_ids or project_ids)

    warnings: list[str] = []
    for project_id in project_ids:
        if not _project_meta_path(workspace, project_id).is_file():
            warnings.append(f"project {project_id} has no local meta; it contributes no task scope")

    if not _inotify_available():
        return {
            **base,
            "ok": False,
            "error": "unsupported_platform",
            "message": (
                "wait_for_change requires inotify (Linux); this runtime "
                f"platform ({os.name}/{sys.platform}) cannot provide event wakes"
            ),
        }

    events_dir = _events_dir(workspace, team)
    tasks_root = workspace / "shared" / "tasks"
    try:
        events_dir.mkdir(parents=True, exist_ok=True)
        tasks_root.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return {
            **base,
            "ok": False,
            "error": "io_error",
            "message": f"cannot prepare watched directories: {exc}",
        }

    # The "查一次": one best-effort mirror pull of the watched streams
    # before the snapshot (the runtime push loop is outbound-only, so the
    # wait would otherwise observe a stale mirror).
    refresh = _refresh_mirror(args, team, task_ids, project_ids)

    watcher = _InotifyWatcher()
    try:
        start = time.monotonic()
        scope = _scope_for_rescan(task_ids, project_ids, workspace)
        _arm_watches(watcher, workspace, team, events_dir, tasks_root, scope, project_ids)
        seen_events = _known_event_ids(events_dir)
        snapshot_task_states = _task_states(workspace, scope)

        satisfied_by: str | None = None
        event: dict[str, Any] | None = None
        task_states = snapshot_task_states
        satisfied_by, event = _evaluate(
            task_scope=frozenset(scope),
            target_statuses=frozenset(target_statuses_raw),
            target_event_types=frozenset(target_event_types_raw),
            change_only=change_only,
            snapshot_task_states=snapshot_task_states,
            task_states=task_states,
            fresh_events=[],
        )
        while satisfied_by is None:
            remaining = deadline - (time.monotonic() - start)
            if remaining <= 0:
                break
            watcher.poll(remaining)
            if time.monotonic() - start >= deadline:
                break  # poll returned on its timeout: no wake arrived
            watcher.drain()
            scope = _scope_for_rescan(task_ids, project_ids, workspace)
            _arm_watches(watcher, workspace, team, events_dir, tasks_root, scope, project_ids)
            task_states = _task_states(workspace, scope)
            fresh = _new_events(
                events_dir,
                seen_events,
                frozenset(scope),
                frozenset(target_event_types_raw),
                scope_filter,
            )
            satisfied_by, event = _evaluate(
                task_scope=frozenset(scope),
                target_statuses=frozenset(target_statuses_raw),
                target_event_types=frozenset(target_event_types_raw),
                change_only=change_only,
                snapshot_task_states=snapshot_task_states,
                task_states=task_states,
                fresh_events=fresh,
            )

        # Deadline final rescan: a change landing exactly at the deadline
        # still counts (the wake and the deadline are racing).
        if satisfied_by is None:
            scope = _scope_for_rescan(task_ids, project_ids, workspace)
            task_states = _task_states(workspace, scope)
            fresh = _new_events(
                events_dir,
                seen_events,
                frozenset(scope),
                frozenset(target_event_types_raw),
                scope_filter,
            )
            satisfied_by, event = _evaluate(
                task_scope=frozenset(scope),
                target_statuses=frozenset(target_statuses_raw),
                target_event_types=frozenset(target_event_types_raw),
                change_only=change_only,
                snapshot_task_states=snapshot_task_states,
                task_states=task_states,
                fresh_events=fresh,
            )

        project_states = _project_states(workspace, project_ids)
        waited = round(time.monotonic() - start, 3)
        result: dict[str, Any] = {
            **base,
            "status": "changed" if satisfied_by is not None else "timeout",
            "satisfiedBy": satisfied_by,
            "selector": {
                "team": team,
                "taskIds": task_ids,
                "projectIds": project_ids,
                "statuses": target_statuses_raw,
                "eventTypes": target_event_types_raw,
            },
            "deadline": deadline,
            "waitedSeconds": waited,
            "event": event,
            "taskStates": task_states,
            "refresh": refresh,
        }
        if project_ids:
            result["projectStates"] = project_states
        if warnings:
            result["warnings"] = warnings
        if satisfied_by is None:
            result["message"] = (
                f"no change matching the selector within {deadline:g}s of the "
                "local mirror. Re-evaluate: re-call with a fresh deadline "
                "(a fresh wait re-pulls the mirror) or escalate; do not "
                "retry unboundedly."
            )
        else:
            result["message"] = (
                f"selector satisfied via the {satisfied_by} facet after {waited}s"
            )
            if action is not None:
                # Echo only: the tool never executes, schedules, or mutates
                # the action — continuing is the caller's decision.
                result["action"] = action
        return result
    finally:
        watcher.close()
