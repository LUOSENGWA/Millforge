"""Inbound priority and the steer capability (TH-22, H4a/H4b).

The Matrix side decides priority at normalisation time (H4b):

- a message from a human that does NOT @-mention us is a human-first
  message -> ``"high"``;
- an @mention addressed to us (the task queue) or a message from one
  of our own agents -> ``"normal"``.

The value rides ``InboundEvent.priority`` (default ``"normal"`` —
events without it keep the pre-TH-22 behaviour).  Whether a
high-priority event can actually preempt the in-flight turn is the
``steer`` runtime capability (H4a): runtimes declare ``{"steer":
false}`` in their hello, and consumers degrade to *next turn, first
thing* — never an error (:func:`inbound_delivery_mode`).

This module is pure (no matrix-nio import) so the core package keeps
its transport-free boundary.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence

from .sidecar import CAP_STEER, capability_supported

PRIORITY_NORMAL = "normal"
PRIORITY_HIGH = "high"

# Lower rank = more urgent.  Unknown values rank as ``normal``
# (degrade, never raise).
PRIORITY_RANK = {PRIORITY_HIGH: 0, PRIORITY_NORMAL: 1}


def determine_inbound_priority(
    sender: str,
    own_user_id: str,
    *,
    mentions: Iterable[str] = (),
    human_matrix_ids: frozenset[str] | set[str] | tuple[str, ...] | None = None,
) -> str:
    """Decide the inbound priority of one event (H4b rule).

    - empty sender -> ``normal`` (nothing to reason about);
    - the sender is ourselves -> ``normal`` (self-echo);
    - with a human roster (*human_matrix_ids* not None) the rule is
      exact: ``high`` iff the sender is a registered human;
    - without a roster the rule needs our own id to tell "addressed to
      us" (an @mention is the task queue -> ``normal``) from "a human
      talking to us" (``high``).  No own id -> ``normal``: the rule
      cannot be applied, and ``normal`` is the conservative side.
      With an own id but no roster we cannot distinguish an agent
      sender from a human one (documented best-effort: any non-self,
      non-@us sender ranks ``high``).
    """
    if not sender:
        return PRIORITY_NORMAL
    if own_user_id and sender == own_user_id:
        return PRIORITY_NORMAL
    if human_matrix_ids is not None:
        return PRIORITY_HIGH if sender in human_matrix_ids else PRIORITY_NORMAL
    if not own_user_id:
        return PRIORITY_NORMAL
    if own_user_id in tuple(mentions):
        return PRIORITY_NORMAL
    return PRIORITY_HIGH


def priority_rank(priority: object) -> int:
    """Sort rank of *priority*; unknown values degrade to ``normal``."""
    return PRIORITY_RANK.get(priority, PRIORITY_RANK[PRIORITY_NORMAL])


def sorted_by_priority(items: Sequence, rank_of) -> list:
    """Stable high-first order: rank by ``rank_of(item)``; ties keep
    their input (arrival) order."""
    return sorted(items, key=lambda item: priority_rank(rank_of(item)))


def steer_supported(capabilities) -> bool:
    """Whether the peer declares ``steer`` (H4a degradation gate).

    Never raises: missing / unknown / malformed input degrades to
    ``False`` (a malformed hello is already rejected on the wire).
    """
    return capability_supported(capabilities, CAP_STEER)


def inbound_delivery_mode(capabilities) -> str:
    """How a high-priority inbound reaches the consumer.

    ``"steer"`` — the runtime can inject it into the in-flight turn;
    ``"next_turn"`` — steer is declared false or absent: the message
    is delivered and handled first on the next turn, without error.
    """
    return "steer" if steer_supported(capabilities) else "next_turn"
